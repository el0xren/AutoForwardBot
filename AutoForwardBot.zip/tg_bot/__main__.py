from .tg_bot import TG_UBOT

TG_UBOT().run()
